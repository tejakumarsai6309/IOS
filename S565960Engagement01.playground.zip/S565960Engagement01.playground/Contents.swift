// 1. What is Swift and provide a brief overview of it.
print("Swift is a programming language developed by Apple. It is designed for building applications for all the apple products. Swift is known for its safety features,usability, and performance.")


// 2. Declare a constant named sID and assign your SID to it. Declare a variable named fullname and assign your full name to it. Print them to the console using string interpolation.
let sID = "S565960"
var fullname = "Teja Kumar Muppala"
print("sID: \(sID), Full Name: \(fullname)")


// 3. Is Bool a data type in Swift, if yes please justify your answer?
print("Yes, Bool is a data type in Swift. It represents a binary value, either true or false. It is commonly used for conditional statements and logical operations.")


// 4. Which among the two (i.e. Double or Float) has more precision digits? Please provide a valid justification.
print("Double has more precision digits than Float. Double is a 64-bit floating-point type, while Float is a 32-bit floating-point type. The increased bit size allows Double to represent a larger range of values with greater precision.")


// 5. Convert an integer 73 into binary, octal, and hexadecimal and print them one by one.
let decimalNumber = 73
print("Binary: \(String(decimalNumber, radix: 2)), Octal: \(String(decimalNumber, radix: 8)), Hexadecimal: \(String(decimalNumber, radix: 16))")


// 6. What is the difference between Int32 and UInt32?
print("Int32 is a signed 32-bit integer type, capable of representing both positive and negative values. UInt32 is an unsigned 32-bit integer type, representing only non-negative values. The 'U' in UInt32 stands for 'unsigned'.")


// 7. Explain the difference between using + operator for string concatenation and string interpolation.
let firstName = "Teja Kumar"
let lastName = "Muppala"
print("String Concatenation: " + firstName + " " + lastName)
print("String Interpolation: \(firstName) \(lastName)")
//both  string concatenation and string interpolation will produces the same output but string interpolation is oftern used in swift because it is easy to use.


// 8. Consider a constant named num, which is of type Int has taken a value of 300. Assign it to another constant named anotherNum, which is of type Int8. Print the value of anotherNum.
let num: Int = 300
let anotherNum: Int8 = Int8(truncatingIfNeeded: num)
print("anotherNum: \(anotherNum)")



// 9. Compare the methods print(_:separator:terminator:) and debugPrint(_:separator:terminator:) in Swift by printing the constant sID you created above.
print("Using print():", terminator: " ")
print(sID)
debugPrint("Using debugPrint():", terminator: " ")
debugPrint(sID)
//print("Using print():", terminator: " ") is used for general purpose
//debugPrint("Using debugPrint():", terminator: " ") is generally used for development and debugging purpose


// 10. Consider the string age and assign it a value of 21. Print the value of age after 3 years from now.
var Stringage = "21"
if let Intage = Int(Stringage) {
    let futureAge = Intage + 3
    print("Age after 3 years: \(futureAge)")
} else {
    print("Invalid age value.")
}




//11.
func reverseNumber(_ num: Int) -> Int {
    return Int(String(String(num).reversed()))!
}

func addTwoNumbers(_ number1: Int, _ number2: Int) -> String {
    
    let reversedNum1 = reverseNumber(number1)
    let reversedNum2 = reverseNumber(number2)
    
    let sumOfReversedNumbers = reversedNum1 + reversedNum2
    
    
    let result = String(reverseNumber(sumOfReversedNumbers))
    
    return result
}
let result = addTwoNumbers(109, 995)
print(result)



